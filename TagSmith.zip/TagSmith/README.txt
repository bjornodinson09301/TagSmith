TagSmith is a simple app to generate secure passwords and creative gamertags.

How to Use

Download tagsmith.exe and place it anywhere you like.

Double-click tagsmith.exe to open the app.

Click Generate Password to create a strong password.

Click Generate Gamertag to get unique gamertags.

Click About to see version info.

Enjoy quick, safe, and fun password and gamertag generation!

Version: 1.0

Made by: Björn Vidar Odinson