import random
import string
import tkinter as tk
from tkinter import simpledialog, messagebox, PhotoImage
import sys
import os

# ---------------- Helper for PyInstaller ----------------
def resource_path(relative_path):
    """ Get absolute path to resource, works for dev and PyInstaller """
    try:
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)

# ---------------- Password Generator ----------------
def generate_password(length=12):
    characters = string.ascii_letters + string.digits + string.punctuation
    password = ''.join(random.choice(characters) for _ in range(length))
    return password

def show_password():
    length = simpledialog.askinteger("Password Generator", "Password length (max 24):", initialvalue=12, minvalue=4, maxvalue=24)
    if length:
        pw = generate_password(length)
        # Copy to clipboard
        root.clipboard_clear()
        root.clipboard_append(pw)
        root.update()  # ensures clipboard is updated
        messagebox.showinfo("Generated Password", f"{pw}\n\nCopied to clipboard!")

# ---------------- Gamertag Generator ----------------
adjectives = [
    "Crazy","Epic","Savage","Silent","Flying","Dark","Mighty","Lucky","Shadow","Furious",
    "Hot","Neo","Max","Wild","Rapid","Ghostly","Thunder","Blazing","Stealthy","Vicious",
    "Electric","Frosty","Inferno","Quantum","Atomic","Cyber","Turbo","Hyper","Legendary","Brave",
    "Swift","Clever","Fiery","Frozen","Shiny","Daring","Bold","Funky","Stormy","Galactic",
    "Invisible","Radiant","Magical","Sonic","Luminous","Feral","Atomic","Dynamic","Fearless","Lucky",
    "Vivid","Epic","Heroic","Noble","Cosmic","Frost","Infernal","Mystic","Lively","Thunderous",
    "Rapid","Flying","Shadowy","Brilliant","Titanic","Furious","Blazing","Savage","Cunning","Silent",
    "Phantom","Majestic","Scarlet","Golden","Crimson","Obsidian","Iron","Steel","Flaming","Vortex",
    "Atomic","Raging","Frozen","Swift","Epic","Neon","Solar","Lunar","Galactic","Turbo",
    "Fierce","Rapid","Brave","Mighty","Wild","Epic","Crazy","Legendary","Dark","Frosty",
    "Storm","Blaze","Shadow","Thunder","Inferno","Nova","Hyper","Cosmic","Quantum","Mystic"
]

nouns = [
    "Penguin","Dragon","Wizard","Ninja","Ghost","Tiger","Wolf","Samurai","Rogue","Phoenix",
    "Fox","Cat","Bat","Jet","Cub","Shadow","Blaze","Specter","Vortex","Falcon",
    "Knight","Raptor","Reaper","Storm","Titan","Venom","Hunter","Slayer","Bolt","Phantom",
    "Bear","Lion","Eagle","Hawk","Shark","Panther","Jaguar","Dragonfly","Cobra","Tigerclaw",
    "Falconer","Samurai","Rogue","Wizard","Phoenix","Wolfpack","Wolfie","Dragonheart","Ironclad","Stormer",
    "Shadow","Blitz","Viper","Frostbite","Firestorm","Lightning","Thunder","Comet","Meteor","Nova",
    "Blizzard","Cyclone","Hurricane","Tornado","Inferno","Avalanche","Specter","Phantom","Vortex","Tempest",
    "Rogue","Ninja","Samurai","Ghost","Titan","Slayer","Hunter","Predator","Bolt","Shadow",
    "Falcon","Tiger","Dragon","Wolf","Panther","Phoenix","Lion","Bear","Jaguar","Hawk",
    "Falconer","Jet","Cub","Bat","Fox","Dragonfly","Cobra","Wolfie","Storm","Blaze",
    "Shadow","Lightning","Thunder","Inferno","Frost","Nova","Comet","Meteor","Vortex","Phantom","Menace"
]

symbols = ["!", "?", "@", "&", "$", "*", "~", "^"]

def generate_gamertag(max_length=12, add_number=True, add_symbol=True):
    adj = random.choice(adjectives)
    noun = random.choice(nouns)
    number = str(random.randint(0, 99)) if add_number else ""
    symbol = random.choice(symbols) if add_symbol else ""
    
    tag = adj + noun + number + symbol
    tag = tag[:max_length]
    return tag

def show_gamertag():
    count = simpledialog.askinteger("Gamertag Generator", "How many gamertags?", initialvalue=5, minvalue=1, maxvalue=20)
    if count:
        tags = [generate_gamertag() for _ in range(count)]
        result = "\n".join(tags)
        # Copy first generated tag to clipboard
        root.clipboard_clear()
        root.clipboard_append(tags[0])
        root.update()
        messagebox.showinfo("Generated Gamertags", f"{result}\n\nFirst tag copied to clipboard!")

# ---------------- GUI Setup ----------------
root = tk.Tk()
root.title("TagSmith")
root.geometry("400x550")
root.configure(bg="#f0f0f0")
root.resizable(False, False)

# ---------------- Add Logo ----------------
logo = PhotoImage(file=resource_path("TSLOGO.png"))
logo = logo.subsample(2,2)  # shrink if needed
logo_label = tk.Label(root, image=logo, bg="#f0f0f0")
logo_label.pack(pady=15)

# Set window icon (taskbar)
try:
    root.iconphoto(True, PhotoImage(file=resource_path("TSLOGO.png")))
except Exception as e:
    print("Could not set taskbar icon:", e)

# ---------------- Style buttons ----------------
button_style = {"width": 25, "height": 2, "bg": "#4CAF50", "fg": "white", "font": ("Arial", 12, "bold")}

pw_button = tk.Button(root, text="Generate Password", command=show_password, **button_style)
pw_button.pack(pady=10)

gt_button = tk.Button(root, text="Generate Gamertag", command=show_gamertag, **button_style)
gt_button.pack(pady=10)

# About button
def show_about():
    messagebox.showinfo("About", "TagSmith v1.2\nBy Björn Vidar Odinson")

about_button = tk.Button(root, text="About", command=show_about, **button_style)
about_button.pack(pady=10)

root.mainloop()
